//package Ex4InterfacesAndAbstraction.Pr2MultipleImplementation;

public interface Identifiable {
    String getId();
}
