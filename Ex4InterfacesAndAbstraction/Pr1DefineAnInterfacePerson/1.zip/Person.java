//package Ex4InterfacesAndAbstraction.Pr1DefineAnInterfacePerson;

public interface Person {
    String getName();
    int getAge();
}
