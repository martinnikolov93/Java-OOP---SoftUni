//package Ex4InterfacesAndAbstraction.Pr4FoodShortage;

public interface Identifiable {
    String getId();
}
