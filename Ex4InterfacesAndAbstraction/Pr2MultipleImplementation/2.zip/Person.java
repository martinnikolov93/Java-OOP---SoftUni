//package Ex4InterfacesAndAbstraction.Pr2MultipleImplementation;

public interface Person {
    String getName();
    int getAge();
}
