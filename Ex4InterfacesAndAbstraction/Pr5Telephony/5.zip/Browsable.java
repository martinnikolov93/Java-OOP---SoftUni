//package Ex4InterfacesAndAbstraction.Pr5Telephony;

public interface Browsable {
    String browse();
}
