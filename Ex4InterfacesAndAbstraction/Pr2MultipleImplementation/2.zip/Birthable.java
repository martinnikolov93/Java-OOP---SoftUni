//package Ex4InterfacesAndAbstraction.Pr2MultipleImplementation;

public interface Birthable {
    String getBirthDate();
}
