//package Ex4InterfacesAndAbstraction.Pr4FoodShortage;

public interface Person {
    String getName();
    int getAge();
}
