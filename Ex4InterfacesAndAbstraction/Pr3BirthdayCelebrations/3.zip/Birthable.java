//package Ex4InterfacesAndAbstraction.Pr3BirthdayCelebrations;

public interface Birthable {
    String getBirthDate();

}
