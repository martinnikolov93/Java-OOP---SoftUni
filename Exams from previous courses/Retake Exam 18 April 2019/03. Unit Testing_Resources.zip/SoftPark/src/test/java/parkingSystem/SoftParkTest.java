package parkingSystem;


public class SoftParkTest {
  //TODO: TEST ALL THE FUNCTIONALITY OF THE PROVIDED CLASS SoftPark
}