//package Ex4InterfacesAndAbstraction.Pr4FoodShortage;

public interface Birthable {
    String getBirthDate();
}
