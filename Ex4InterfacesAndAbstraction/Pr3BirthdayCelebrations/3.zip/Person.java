//package Ex4InterfacesAndAbstraction.Pr3BirthdayCelebrations;

public interface Person {
    String getName();
    int getAge();
}
