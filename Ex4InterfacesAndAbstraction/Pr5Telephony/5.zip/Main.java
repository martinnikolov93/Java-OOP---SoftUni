//package Ex4InterfacesAndAbstraction.Pr5Telephony;

public class Main {
    public static void main(String[] args) {

    }
}
