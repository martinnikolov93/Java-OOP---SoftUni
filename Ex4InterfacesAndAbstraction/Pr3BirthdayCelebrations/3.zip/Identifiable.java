//package Ex4InterfacesAndAbstraction.Pr3BirthdayCelebrations;

public interface Identifiable {
    String getId();
}
