//package Ex4InterfacesAndAbstraction.Pr4FoodShortage;

public class Main {
    public static void main(String[] args) {

    }
}
